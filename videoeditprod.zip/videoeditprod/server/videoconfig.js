module.exports = {
    host: '10.1.14.23',
    port: 8080,
    path: '/UserPoint/UserPointTreeServ',
    method: 'POST',
    headers: {
        'Content-Type': 'application/xml;charset=GB2312'
    }
};