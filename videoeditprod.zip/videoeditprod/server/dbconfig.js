module.exports = {
    mysql: {
        // host: "rdsex303883f1763h8rwr.mysql.rds.pcloud.ga",
        host: "192.168.1.22",
        port: 3306,
        // user: "pgis",
        // password: "pgisdb",
        user: "qian",
        password: "qian",
        database: "videodb"
    }
};